<?php
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $databasename = 'login';

    $conn = mysqli_connect($servername, $username, $password, $databasename);
    if(!$conn){
        die("Can not connect to the database". mysqli_connect_error());
    }
    else{
        
    }
?>